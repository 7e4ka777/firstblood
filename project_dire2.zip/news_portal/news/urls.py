from django.urls import path
from .views import PostsList, PostDetail, SearchPosts, PostCreate, PostUpdate, PostDelete, CategoryList, CategoryDetail, add_subscribe, del_subscribe
urlpatterns = [
    path('news/', PostsList.as_view(), name='post_list'),
    path('news/<int:pk>', PostDetail.as_view(), name='post_detail'),
    path('news/search/', SearchPosts.as_view(), name='search_posts'),
    path('news/create/', PostCreate.as_view(), name='news_list'),
    path('articles/create/', PostCreate.as_view(), name='arts_list'),
    path('news/<int:pk>/update/', PostUpdate.as_view(), name='news_update'),
    path('articles/<int:pk>/update/', PostUpdate.as_view(), name='arts_update'),
    path('news/<int:pk>/delete/', PostDelete.as_view(), name='news_delete'),
    path('articles/<int:pk>/delete/', PostDelete.as_view(), name='arts_delete'),
    path('articles/<int:pk>/delete/', PostDelete.as_view(), name='arts_delete'),
    path('news/categories/', CategoryList.as_view(), name='categories'),
    path('news/categories/<int:pk>/add_subscribe/', add_subscribe, name='add_subscribe'),
    path('news/categories/<int:pk>/del_subscribe/', del_subscribe, name='del_subscribe'),
    path('news/categories/<int:pk>/', CategoryDetail.as_view(), name='category_subscription'),
]
