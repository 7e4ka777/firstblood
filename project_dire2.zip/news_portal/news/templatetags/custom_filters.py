from django import template

register = template.Library()

@register.filter
def censor(value: str):
    Banned_List = ['coming', 'Coming', 'fashion', 'Fashion', 'Westwood', 'westwood']
    sentence = value.split()
    for i in Banned_List:
        for word in sentence:
            if i in word:
                pos = sentence.index(word)
                sentence.remove(word)
                sentence.insert(pos, word[0] + '*' * (len(word)-1))
    return " ".join(sentence)