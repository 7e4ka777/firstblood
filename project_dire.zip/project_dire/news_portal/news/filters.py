from django.forms import DateInput
from django_filters import FilterSet, CharFilter, \
    DateFilter, ModelChoiceFilter

from .models import Post, Author


class PostFilter(FilterSet):
    title = CharFilter('title',
                       label='Заголовок содержит:',
                       lookup_expr='icontains',
                       )

    author = ModelChoiceFilter(field_name='author',
                                       label='Автор:',
                                       lookup_expr='exact',
                                       queryset=Author.objects.all(),
                                       empty_label='любой'
                                       )
    datetime = DateFilter(
        field_name='date_time',
        widget=DateInput(attrs={'type': 'date', 'class': "form-control"}),
        lookup_expr='gt',
        label='Дата размещения позже'
    )

    class Meta:
        model = Post
        fields = []