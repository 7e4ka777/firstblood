from django.db import models
from django.contrib.auth.models import User
from django.db.models import Sum
from django.urls import reverse
from django.template.loader import render_to_string
from django.core.mail import EmailMultiAlternatives

class Author(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    rating = models.SmallIntegerField(default=0)

    def update_rating(self):
        posts_rating = self.posts.aggregate(result=Sum('rating')).get('result')
        comments_rating = self.user.comments.aggregate(result=Sum('rating')).get('result')
        rating_all_comment = Comment.objects.filter(post_id__author_id=self.pk).aggregate(Sum('rating'))['rating__sum']
        self.rating = 3 * posts_rating + comments_rating + rating_all_comment
        self.save()
        print(f'Рейтинг = {self.rating}')

    def __str__(self):
        return f'{self.user}'


class Category(models.Model):
    name = models.CharField(unique=True, max_length=128)
    subscribers = models.ManyToManyField(User, through='UserCategory')

    def __str__(self):
        return f'{self.name}'


class Post(models.Model):
    news = 'NW'
    article = 'AR'
    CATEGORY_CHOISES = [
        (news, 'Новость'),
        (article, 'Статья')
    ]
    author = models.ForeignKey(Author, on_delete=models.CASCADE, related_name='posts')
    post_type = models.CharField(max_length=2, choices=CATEGORY_CHOISES, default=article)
    date_time = models.DateTimeField(auto_now_add=True)
    category = models.ManyToManyField(Category, through='PostCategory')
    title = models.CharField(max_length=128)
    text = models.TextField()
    rating = models.SmallIntegerField(default=0)

    @staticmethod
    def send_email_to_subscribers(user, category, title, text, receivers_id, url):
        for _ in receivers_id:
            to_send = User.objects.filter(id=_['sub_user_id']).values('first_name', 'last_name', 'username', 'email')
            html_content = render_to_string(
                'news_created.html',
                {
                    'title': title,
                    'text': text,
                    'cur_user': user,
                    'category': category,
                    'url': url,
                    'user': f"{to_send[0]['first_name']} {to_send[0]['last_name']} ({to_send[0]['username']})"
                }
            )
            msg = EmailMultiAlternatives(
                subject=title,
                body=text[:50],  # это то же, что и message
                from_email='semenyak7@yandex.ru',
                to=[to_send[0]['email']],  # это то же, что и recipients_list
            )
            msg.attach_alternative(html_content, "text/html")  # добавляем html
            msg.send()

        return

    def like(self):
        self.rating += 1
        self.save()

    def dislike(self):
        self.rating -= 1
        self.save()

    def preview(self, length=124):
        return f'{self.text[:length]}...' if len(self.text) > length else self.text

    def __str__(self):
        return f'{self.title}'

    def get_absolute_url(self):
        return reverse('post_detail', args=[str(self.id)])


class PostCategory(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)


class UserCategory(models.Model):
    sub_user = models.ForeignKey(User, on_delete=models.CASCADE)
    sub_categories = models.ForeignKey(Category, on_delete=models.CASCADE)


class Comment(models.Model):
    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='comments2')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='comments')
    text = models.TextField()
    date_time = models.DateTimeField(auto_now_add=True)
    rating = models.SmallIntegerField(default=0)

    def like(self):
        self.rating += 1
        self.save()

    def dislike(self):
        self.rating -= 1
        self.save()


class NewsCreated(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    date = models.DateField(auto_now_add=False)
    count = models.IntegerField(default=0)

    def __str__(self):
        return f'{self.id}: {self.user_id} - {self.user}: {self.date}: {self.count}'