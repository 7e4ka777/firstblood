from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from .models import Post, Category, NewsCreated
from .filters import PostFilter
from .forms import PostForm
from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import TemplateView
from django.contrib.auth.mixins import PermissionRequiredMixin
from django.shortcuts import redirect
from django.contrib.auth.decorators import login_required
from datetime import date
# from django.template.loader import render_to_string
# from django.core.mail import EmailMultiAlternatives

class PostsList(ListView):
    model = Post
    ordering = '-date_time'
    template_name = 'posts.html'
    context_object_name = 'posts'
    paginate_by = 2


class SearchPosts(ListView):
    paginate_by = 3
    model = Post
    ordering = '-date_time'
    template_name = 'search.html'
    context_object_name = 'posts'

    def get_queryset(self):
        queryset = super().get_queryset()
        self.filterset = PostFilter(self.request.GET, queryset)
        return self.filterset.qs

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['filterset'] = self.filterset
        return context


class PostDetail(DetailView):
    model = Post
    template_name = 'post.html'
    context_object_name = 'post'


class PostCreate(PermissionRequiredMixin, CreateView):
    form_class = PostForm
    model = Post
    template_name = 'post_edit.html'
    permission_required = ('news.add_post',)

    def check(self, request, *args, **kwargs):
        if NewsCreated.objects.filter(user_id=self.request.user.id, date=date.today()).exists():
            if NewsCreated.objects.filter(user_id=self.request.user.id, date=date.today()).values('count')[0]['count'] < 3:
                return super().post(self, request, *args, **kwargs)
            else:
                return redirect(request.META.get('HTTP_REFERER'))

        return super().post(self, request, *args, **kwargs)

    def form_valid(self, form):
        post = form.save(commit=False)

        if 'news' in self.request.path.split('/'):
            post.post_type = 'NW'
            self.success_url = reverse_lazy('news_list')
        else:
            post.post_type = 'AR'
            self.success_url = reverse_lazy('arts_list')

        return super().form_valid(form)

    # def post(self, request, *args, **kwargs):
    #     form = PostForm(request.POST)
    #     post_category_pk = request.POST['category']
    #     sub_text = request.POST.get('text')
    #     sub_title = request.POST.get('title')
    #     post_category = Category.objects.get(pk=post_category_pk)
    #     subscribers = post_category.subscribers.all()
    #     host = request.META.get('HTTP_HOST')
    #     if form.is_valid():
    #         news = form.save(commit=False)
    #         news.save()
    #     for subscriber in subscribers:
    #         html_content = render_to_string(
    #             'mail.html',
    #             {'user': subscriber, 'text': sub_text[:50], 'post': news, 'title': sub_title, 'host': host}
    #         )
    #         msg = EmailMultiAlternatives(
    #             subject=f'Здравствуй, {subscriber.username}. Новая статья в твоем любимом разделе!',
    #             body=f'{sub_text[:50]}',
    #             from_email='semenyak7@yandex.ru',
    #             to=[subscriber.email],
    #         )
    #         msg.attach_alternative(html_content, "text/html")
    #         msg.send()
    #     return redirect('/news/')
    #

class PostUpdate(PermissionRequiredMixin, LoginRequiredMixin, UpdateView):
    form_class = PostForm
    model = Post
    template_name = 'post_edit.html'
    permission_required = ('news.change_post',)

    def form_valid(self, form):
        post = form.save(commit=False)

        if 'news' in self.request.path.split('/'):
            post.post_type = 'NW'
            self.success_url = reverse_lazy('news_update')
        else:
            post.post_type = 'AR'
            self.success_url = reverse_lazy('arts_update')

        return super().form_valid(form)


class PostDelete(DeleteView):
    model = Post
    template_name = 'post_delete.html'

    def form_valid(self, form):
        post = form.save(commit=False)

        if 'news' in self.request.path.split('/'):
            post.post_type = 'NW'
            self.success_url = reverse_lazy('news_delete')
        else:
            post.post_type = 'AR'
            self.success_url = reverse_lazy('arts_delete')

        return super().form_valid(form)


class ProtectedView(LoginRequiredMixin, TemplateView):
    template_name = 'protected_page.html'

class CategoryList(ListView):
    model = Category
    template_name = 'category_list.html'
    context_object_name = 'categories'


class CategoryDetail(DetailView):
    template_name = 'category_subscription.html'
    model = Category

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        category_id = self.kwargs.get('pk')
        category_subscribers = Category.objects.filter(pk=category_id).values("subscribers__username")
        context['is_not_subscribe'] = not category_subscribers.filter(subscribers__username=self.request.user).exists()
        context['is_subscribe'] = category_subscribers.filter(subscribers__username=self.request.user).exists()
        return context

@login_required
def add_subscribe(request, **kwargs):
    pk = request.GET.get('pk', )
    print('Пользователь', request.user, 'добавлен в подписчики категории:', Category.objects.get(pk=pk))
    Category.objects.get(pk=pk).subscribers.add(request.user)
    return redirect('/news/')

def del_subscribe(request, **kwargs):
    pk = request.GET.get('pk', )
    print('Пользователь', request.user, 'удален из подписчиков категории:', Category.objects.get(pk=pk))
    Category.objects.get(pk=pk).subscribers.remove(request.user)
    return redirect('/news/')






